import json
from datetime import datetime

def lambda_handler(event, context):
    currentTime = datetime.now()
    data = {'greeting': 'Hello from BSD UChicago Lambda!', 'time-is': str(currentTime)}
    print(json.dumps(data))
    return {
        'statusCode': 200,
        'body': json.dumps(data)
    }
